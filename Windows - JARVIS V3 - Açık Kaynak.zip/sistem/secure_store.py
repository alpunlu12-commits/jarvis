"""
Yerel sifreleme — Windows DPAPI (Data Protection API) uzerinden.

API anahtari gibi hassas degerleri diskte DUZ METIN olarak tutmak yerine
sifreler. Bu, Chrome/Edge'in kayitli sifreleri korumak icin kullandigi
AYNI mekanizmadir: sifre cozme islemi yalnizca SIFRELEYEN Windows
kullanicisiyla + AYNI bilgisayarda mumkundur. Dosya kopyalanip baska bir
bilgisayara tasinsa bile cozulemez.

Ekstra bagimlilik GEREKMEZ — pywin32 zaten Windows icin gerekli bir paket
(requirements.txt'te sys_platform == "win32" ile zaten listeli).

Windows disi ortamlarda (gelistirme/macOS) veya DPAPI basarisiz olursa
sifreleme sessizce atlanir; deger oldugu gibi (duz metin) doner. Boylece
bu modul EN KOTU ihtimalle eski davranisa (duz metin) geri duser, JARVIS'i
hicbir zaman calismaz hale getirmez.
"""

from __future__ import annotations

import base64

from actions.platform_utils import IS_WIN

# Sifrelenmis degerleri duz metinden ayirt etmek icin onek.
# Boylece eski (sifresiz) config dosyalariyla geriye donuk uyumluyuz.
ENC_PREFIX = "dpapi:"

# JARVIS disinda baska bir uygulamanin ayni kullanicidaki DPAPI verisini
# yanlislikla cozmesini/karistirmasini biraz daha zorlastiran "entropy" etiketi.
# Gizlilik icin gerekli degil (DPAPI zaten kullanici anahtarina bagli),
# yalnizca ek bir baglam etiketi.
_ENTROPY = b"JARVIS-v3-config"


def _dpapi_encrypt(plaintext: str) -> bytes | None:
    try:
        import win32crypt
        return win32crypt.CryptProtectData(
            plaintext.encode("utf-8"), "JARVIS config", _ENTROPY, None, None, 0
        )
    except Exception:
        return None


def _dpapi_decrypt(blob: bytes) -> str | None:
    try:
        import win32crypt
        _desc, data = win32crypt.CryptUnprotectData(blob, _ENTROPY, None, None, 0)
        return data.decode("utf-8")
    except Exception:
        return None


def encrypt_value(plaintext: str) -> str:
    """Duz metni sifreler, dogrudan JSON'a yazilabilir bir string doner.

    Sifrelenemezse (Windows disi ortam / DPAPI basarisiz) deger OLDUGU GIBI
    doner — anahtar asla kaybolmaz, en kotu ihtimalle duz metin kalir.
    """
    plaintext = plaintext or ""
    if not plaintext or not IS_WIN:
        return plaintext

    blob = _dpapi_encrypt(plaintext)
    if blob is None:
        return plaintext

    return ENC_PREFIX + base64.b64encode(blob).decode("ascii")


def decrypt_value(stored: str) -> str:
    """encrypt_value ile yazilmis bir degeri okur.

    'dpapi:' oneki yoksa eski/sifresiz bir kayittir — oldugu gibi doner
    (geriye donuk uyumluluk). Onek varsa ama bu makinede cozulemezse
    (baska bilgisayara tasinmis, kullanici profili degismis vb.) bos
    string doner — bu durumda cagiran taraf anahtarin tekrar girilmesini
    ister, sessizce yanlis/bozuk bir deger kullanmaz.
    """
    stored = stored or ""
    if not stored.startswith(ENC_PREFIX):
        return stored

    if not IS_WIN:
        return ""

    try:
        blob = base64.b64decode(stored[len(ENC_PREFIX):])
    except Exception:
        return ""

    plain = _dpapi_decrypt(blob)
    return plain or ""
