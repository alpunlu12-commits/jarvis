"""
Web arama — DuckDuckGo'nun JS'siz "html" uc noktasi uzerinden, API anahtari
GEREKMEZ.

Onemli: Bu resmi/belgelenmis bir API degildir (DuckDuckGo'nun basit HTML
istemcisi kazinir/parse edilir). DuckDuckGo sayfa yapisini degistirirse bu
modul sonuc doneremeyebilir — boyle bir durumda JARVIS'i kilitlemek yerine
acik bir hata metni doneriz, ustteki katman bunu kullaniciya soyler.
"""

from __future__ import annotations

import html as html_lib
import re
from urllib.parse import parse_qs, unquote, urlparse

import requests

from actions.platform_utils import PLATFORM_LABEL

SEARCH_URL = "https://html.duckduckgo.com/html/"
HEADERS = {"User-Agent": f"Mozilla/5.0 (JARVIS {PLATFORM_LABEL}; +https://github.com)"}
REQUEST_TIMEOUT = 12

# <a ... class="result__a" href="...">BASLIK</a> ... class="result__snippet">OZET</a>
_RESULT_RE = re.compile(
    r'class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>.*?'
    r'class="result__snippet"[^>]*>(.*?)</a>',
    re.S,
)


def _strip_tags(fragment: str) -> str:
    fragment = re.sub(r"<[^>]+>", "", fragment)
    return html_lib.unescape(fragment).strip()


def _clean_url(raw: str) -> str:
    """DuckDuckGo sonuclari gercek adresi /l/?uddg=... yonlendirmesiyle sarar."""
    if raw.startswith("//"):
        raw = "https:" + raw
    parsed = urlparse(raw)
    qs = parse_qs(parsed.query)
    if "uddg" in qs and qs["uddg"]:
        return unquote(qs["uddg"][0])
    return raw


def web_search(query: str, max_results: int = 5) -> str:
    query = (query or "").strip()
    if not query:
        return "Arama sorgusu bos olamaz."

    max_results = max(1, min(int(max_results or 5), 8))

    try:
        resp = requests.post(
            SEARCH_URL,
            data={"q": query},
            headers=HEADERS,
            timeout=REQUEST_TIMEOUT,
        )
        resp.raise_for_status()
    except requests.RequestException as e:
        return f"Arama yapilamadi (baglanti hatasi): {e}"

    matches = _RESULT_RE.findall(resp.text)
    if not matches:
        return f"'{query}' icin sonuc bulunamadi (ya da arama servisi gecici olarak yanit vermiyor)."

    lines = [f"'{query}' icin arama sonuclari:"]
    for i, (url, title, snippet) in enumerate(matches[:max_results], start=1):
        clean_title = _strip_tags(title)
        clean_snippet = _strip_tags(snippet)
        clean_url = _clean_url(url)
        lines.append(f"{i}. {clean_title}\n   {clean_snippet}\n   Kaynak: {clean_url}")

    return "\n".join(lines)
