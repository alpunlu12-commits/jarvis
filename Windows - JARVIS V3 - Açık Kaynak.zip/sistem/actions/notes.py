"""
Notlar / gorev listesi — tamamen yerel bir JSON dosyasinda saklanir.
Internet veya API anahtari gerektirmez; hafiza (memory) modulunden farkli
olarak buradaki oge kullanicinin AKTIF gorev/not listesidir (yapilacaklar,
alisveris listesi vb.) — kalici kimlik/tercih bilgisi degil.
"""

from __future__ import annotations

import json
import threading
import uuid
from datetime import datetime

from app_paths import data_path

NOTES_FILE = data_path("notes.json")
_lock = threading.Lock()


def _load() -> list[dict]:
    try:
        if NOTES_FILE.exists():
            with open(NOTES_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list):
                    return data
    except Exception:
        pass
    return []


def _save(items: list[dict]) -> None:
    NOTES_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(NOTES_FILE, "w", encoding="utf-8") as f:
        json.dump(items, f, indent=2, ensure_ascii=False)


def add_note(text: str, list_name: str = "genel") -> str:
    text = (text or "").strip()
    if not text:
        return "Not metni bos olamaz."
    list_name = (list_name or "genel").strip() or "genel"

    with _lock:
        items = _load()
        items.append({
            "id": uuid.uuid4().hex[:8],
            "text": text,
            "list": list_name,
            "done": False,
            "created": datetime.now().isoformat(timespec="seconds"),
        })
        _save(items)

    return f"Not eklendi ({list_name}): {text}"


def get_notes(list_name: str = "", include_done: bool = False) -> str:
    with _lock:
        items = _load()

    list_name = (list_name or "").strip()
    if list_name:
        items = [n for n in items if n.get("list", "genel").lower() == list_name.lower()]
    if not include_done:
        items = [n for n in items if not n.get("done")]

    if not items:
        scope = f" ('{list_name}' listesinde)" if list_name else ""
        return f"Kayitli not yok{scope}."

    lines = []
    for n in items:
        mark = "✓" if n.get("done") else "•"
        lines.append(f"{mark} [{n.get('list', 'genel')}] {n.get('text', '')}")
    return "\n".join(lines)


def complete_note(match_text: str) -> str:
    """Metne gore en yakin eslesen notu 'tamamlandi' isaretler."""
    match_text = (match_text or "").strip().lower()
    if not match_text:
        return "Hangi notun tamamlandigini belirtmelisin."

    with _lock:
        items = _load()
        hit = None
        for n in items:
            if match_text in n.get("text", "").lower():
                hit = n
                break
        if not hit:
            return f"'{match_text}' ile eslesen bir not bulunamadi."
        hit["done"] = True
        _save(items)

    return f"Tamamlandi olarak isaretlendi: {hit['text']}"


def delete_note(match_text: str, delete_all: bool = False) -> str:
    match_text = (match_text or "").strip().lower()
    if not match_text and not delete_all:
        return "Hangi notun silinecegini belirtmelisin."

    with _lock:
        items = _load()
        if delete_all and not match_text:
            count = len(items)
            _save([])
            return f"{count} not silindi (tumu)."

        remaining = [n for n in items if match_text not in n.get("text", "").lower()]
        removed = len(items) - len(remaining)
        _save(remaining)

    if removed == 0:
        return f"'{match_text}' ile eslesen bir not bulunamadi."
    return f"{removed} not silindi."
