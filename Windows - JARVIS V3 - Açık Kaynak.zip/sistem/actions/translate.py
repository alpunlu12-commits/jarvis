"""
Ceviri — MyMemory Translation API uzerinden, API anahtari GEREKMEZ.

Ucretsiz/anonim kullanim gunluk ~5000 kelimeyle sinirlidir (MyMemory'nin
kendi kotasi). Agir kullanimda servis hata donebilir; bu durumda kullaniciya
acik bir mesaj veriyoruz, sessizce basarisiz olmuyoruz.
"""

from __future__ import annotations

import requests

from actions.platform_utils import PLATFORM_LABEL

TRANSLATE_URL = "https://api.mymemory.translated.net/get"
HEADERS = {"User-Agent": f"JARVIS {PLATFORM_LABEL}"}
REQUEST_TIMEOUT = 12

# Kullanicilarin sesli soyleyebilecegi yaygin dil adlari → ISO 639-1 kodu.
# Model (Gemini) zaten dogru kod verebilir; bu sadece bir guvenlik agi.
LANG_ALIASES = {
    "turkce": "tr", "türkçe": "tr", "turkish": "tr", "tr": "tr",
    "ingilizce": "en", "english": "en", "en": "en",
    "almanca": "de", "german": "de", "de": "de",
    "fransizca": "fr", "fransızca": "fr", "french": "fr", "fr": "fr",
    "ispanyolca": "es", "spanish": "es", "es": "es",
    "italyanca": "it", "italian": "it", "it": "it",
    "rusca": "ru", "rusça": "ru", "russian": "ru", "ru": "ru",
    "arapca": "ar", "arapça": "ar", "arabic": "ar", "ar": "ar",
    "japonca": "ja", "japanese": "ja", "ja": "ja",
    "cince": "zh-CN", "çince": "zh-CN", "chinese": "zh-CN",
    "portekizce": "pt", "portuguese": "pt", "pt": "pt",
    "felemenkce": "nl", "hollandaca": "nl", "dutch": "nl", "nl": "nl",
    "yunanca": "el", "greek": "el", "el": "el",
    "korece": "ko", "korean": "ko", "ko": "ko",
    "lehce": "pl", "polish": "pl", "pl": "pl",
    "ukraynaca": "uk", "ukrainian": "uk", "uk": "uk",
    "farsca": "fa", "farsça": "fa", "persian": "fa", "fa": "fa",
    "azerice": "az", "azerbaijani": "az", "az": "az",
}


def _lang_code(name: str, default: str) -> str:
    name = (name or "").strip().lower()
    if not name or name in ("auto", "otomatik"):
        return default
    if name in LANG_ALIASES:
        return LANG_ALIASES[name]
    if 2 <= len(name) <= 5:
        return name  # zaten "tr", "en", "zh-CN" gibi bir kod olabilir
    return default


def translate_text(text: str, target_lang: str, source_lang: str = "") -> str:
    """
    JARVIS Turkce odakli oldugu icin kaynak dil belirtilmezse "tr" varsayilir
    (yani "bunu ingilizceye cevir: merhaba" gibi komutlarda dogru calisir).
    """
    text = (text or "").strip()
    if not text:
        return "Cevrilecek metin bos olamaz."
    if len(text) > 500:
        return "Metin cok uzun; 500 karakterin altinda bir metinle tekrar dene."

    tgt = _lang_code(target_lang, default="en")
    src = _lang_code(source_lang, default="tr")

    if src == tgt:
        return text  # ayni dile "cevirmek" gereksiz, oldugu gibi don

    try:
        resp = requests.get(
            TRANSLATE_URL,
            params={"q": text, "langpair": f"{src}|{tgt}"},
            headers=HEADERS,
            timeout=REQUEST_TIMEOUT,
        )
        resp.raise_for_status()
        data = resp.json()
    except requests.RequestException as e:
        return f"Ceviri yapilamadi (baglanti hatasi): {e}"
    except ValueError:
        return "Ceviri servisi beklenmeyen bir yanit dondurdu."

    payload = data.get("responseData") or {}
    translated = (payload.get("translatedText") or "").strip()

    if not translated or "QUERY LENGTH LIMIT" in translated.upper():
        return "Ceviri alinamadi — servis su an yanit vermiyor olabilir, birazdan tekrar dene."

    return translated
