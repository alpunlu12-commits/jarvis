"""
Hava durumu ozeti — wttr.in uzerinden.

Konum onceligi:
1. Cagriya verilen `location` (kullanici "Ankara'da hava nasil" dediyse)
2. config/api_keys.json → "weather_location"  (elle sabitlemek isteyen icin)
3. JARVIS_WEATHER_LOCATION ortam degiskeni
4. OTOMATIK (Windows): Windows Konum Hizmetleri (GPS/WiFi/IP ucgenleme) —
   kullanici Ayarlar > Gizlilik ve guvenlik > Konum'dan izin vermisse,
   IP tahmininden cok daha hassas enlem/boylam doner.
5. OTOMATIK (yedek): wttr.in istegi ciplak IP'den konumu kendisi tahmin eder.

Eskiden herkes icin "Istanbul" sabitti; artik kullanicinin bulundugu sehir
otomatik tespit ediliyor ve tespit edilen sehir adi onbellege aliniyor.
"""

from __future__ import annotations

import os
import threading
import time

import requests

from actions.platform_utils import IS_WIN, PLATFORM_LABEL, run_powershell

try:
    from app_config import get_app_config_value
except Exception:  # app_config yoksa (tek basina kullanim)
    def get_app_config_value(key, default=None):
        return default


_detected_city = ""          # otomatik bulunan sehir (onbellek)
_lock = threading.Lock()

REQUEST_TIMEOUT = 12
HEADERS = {"User-Agent": f"JARVIS {PLATFORM_LABEL}"}

# Windows Konum Hizmeti sorgusu ~saniyeler surebiliyor; her "hava nasil"
# sorusunda tekrar sormamak icin sonucu bir sure onbellekte tut.
_LOCATION_CACHE_TTL = 600  # saniye (10 dakika)
_win_location_cache: tuple[float, float] | None = None
_win_location_cache_ts = 0.0
_win_location_lock = threading.Lock()


_WINDOWS_LOCATION_SCRIPT = r"""
Add-Type -AssemblyName System.Device
$w = New-Object System.Device.Location.GeoCoordinateWatcher
$w.Start()
$i = 0
while (($w.Status -ne 'Ready') -and ($w.Permission -ne 'Denied') -and ($i -lt 100)) {
    Start-Sleep -Milliseconds 100
    $i++
}
if ($w.Permission -eq 'Denied') {
    Write-Output 'DENIED'
} elseif ($w.Position.Location.IsUnknown) {
    Write-Output 'UNKNOWN'
} else {
    $loc = $w.Position.Location
    Write-Output ("{0},{1}" -f $loc.Latitude, $loc.Longitude)
}
$w.Stop()
"""


def _windows_location(force: bool = False) -> tuple[float, float] | None:
    """Windows Konum Hizmetleri'nden hassas (enlem, boylam) alir.

    Kullanici izin vermediyse (Ayarlar > Gizlilik > Konum > "Masaustu
    uygulamalarinin konumuma erismesine izin ver" kapaliysa) ya da konum
    hic bulunamazsa None doner — cagiran taraf IP tabanli yedege duser.
    """
    if not IS_WIN:
        return None

    global _win_location_cache, _win_location_cache_ts
    with _win_location_lock:
        if not force and _win_location_cache is not None:
            if time.time() - _win_location_cache_ts < _LOCATION_CACHE_TTL:
                return _win_location_cache

    ok, out = run_powershell(_WINDOWS_LOCATION_SCRIPT, timeout=15)
    if not ok or not out.strip():
        return None

    last_line = out.strip().splitlines()[-1].strip()
    if last_line in ("DENIED", "UNKNOWN", ""):
        return None

    try:
        lat_str, lon_str = last_line.split(",")
        coords = (float(lat_str), float(lon_str))
    except Exception:
        return None

    with _win_location_lock:
        _win_location_cache = coords
        _win_location_cache_ts = time.time()
    return coords


def configured_location() -> str:
    """Kullanicinin elle sabitledigi konum (yoksa bos)."""
    value = str(get_app_config_value("weather_location", "") or "").strip()
    if value:
        return value
    return (os.environ.get("JARVIS_WEATHER_LOCATION") or "").strip()


def detected_city() -> str:
    """Otomatik tespit edilen sehir; henuz sorgulanmadiysa bos doner."""
    with _lock:
        return _detected_city


def current_location_label() -> str:
    """Arayuzde gosterilecek konum adi."""
    return configured_location() or detected_city() or "Konum araniyor"


def _extract_city(payload: dict) -> str:
    """
    Sehir adini cikarir.

    wttr.in'in 'areaName' alani cok yerel olabiliyor (Istanbul yerine
    "Kucukpazar", Ankara yerine "Samanpazari"). Kullaniciya sehir adi daha
    anlamli oldugu icin once 'region' tercih edilir.
    """
    try:
        area = (payload.get("nearest_area") or [{}])[0]
        name = ((area.get("areaName") or [{}])[0]).get("value", "").strip()
        region = ((area.get("region") or [{}])[0]).get("value", "").strip()
        return region or name
    except Exception:
        return ""


def get_weather_summary(location: str | None = None) -> str:
    explicit = (location or "").strip()
    target = explicit or configured_location()

    # target bossa once Windows Konum Hizmeti'ni dene (hassas), o da
    # calismazsa wttr.in'e sehir vermeden sorariz — kendisi IP'den bulur.
    coords = None if target else _windows_location()

    if coords:
        lat, lon = coords
        url = f"https://wttr.in/{lat},{lon}"
    else:
        url = f"https://wttr.in/{target}" if target else "https://wttr.in"

    try:
        response = requests.get(
            url, params={"format": "j1"},
            timeout=REQUEST_TIMEOUT, headers=HEADERS,
        )
        response.raise_for_status()
        payload = response.json()
    except Exception:
        known = target or detected_city()
        if known:
            return f"{known} icin hava durumu bilgisi su anda alinamadi."
        return "Hava durumu bilgisi şu anda alınamadı."

    detected = _extract_city(payload)
    if not target and detected:
        # Otomatik bulunan sehri hatirla (arayuz kartinda da kullanilir)
        with _lock:
            global _detected_city
            _detected_city = detected

    # Kullanici acikca bir yer soylediyse ONUN kelimesini kullan:
    # "Ankara" isteyip "Samanpazari" duymak kafa karistirici.
    city = target or detected

    current = (payload.get("current_condition") or [{}])[0]
    temp_c = current.get("temp_C")
    feels_like = current.get("FeelsLikeC")
    weather_desc = ((current.get("weatherDesc") or [{}])[0]).get("value", "")
    humidity = current.get("humidity")

    parts = []
    if temp_c:
        parts.append(f"{temp_c} derece")
    if weather_desc:
        parts.append(weather_desc.lower())
    if feels_like and feels_like != temp_c:
        parts.append(f"hissedilen {feels_like} derece")
    if humidity:
        parts.append(f"nem yüzde {humidity}")

    if not parts:
        return "Hava durumu bilgisi şu anda alınamadı."

    label = city or "Bulunduğun konum"
    return f"{label} için hava durumu: " + ", ".join(parts) + "."
