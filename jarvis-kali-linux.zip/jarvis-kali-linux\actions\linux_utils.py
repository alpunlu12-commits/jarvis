"""
Small Linux desktop/runtime helpers used by JARVIS actions.

The project originally targeted macOS command-line tools. This module keeps
Linux-specific command selection in one place so the action modules stay small.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import time
from pathlib import Path
from typing import Sequence


def command_exists(name: str) -> bool:
    return shutil.which(name) is not None


def jarvis_data_dir() -> Path:
    configured = os.environ.get("JARVIS_DATA_DIR")
    if configured:
        base = Path(configured).expanduser()
    else:
        xdg_data_home = os.environ.get("XDG_DATA_HOME")
        base = Path(xdg_data_home).expanduser() / "jarvis" if xdg_data_home else Path.home() / ".local" / "share" / "jarvis"
    base.mkdir(parents=True, exist_ok=True)
    return base


def run_detached(command: Sequence[str]) -> tuple[bool, str]:
    try:
        subprocess.Popen(
            list(command),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        return True, "ok"
    except FileNotFoundError:
        return False, f"{command[0]} bulunamadi."
    except Exception as exc:
        return False, str(exc)


def open_with_xdg(target: str | Path, timeout: int = 10) -> tuple[bool, str]:
    target_text = str(target)
    if not command_exists("xdg-open"):
        return False, "xdg-open bulunamadi. apt install xdg-utils ile kur."
    try:
        result = subprocess.run(
            ["xdg-open", target_text],
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except subprocess.TimeoutExpired:
        return False, "xdg-open zaman asimina ugradi."
    except Exception as exc:
        return False, str(exc)

    if result.returncode == 0:
        return True, "ok"
    detail = (result.stderr or result.stdout or "").strip()
    return False, detail or f"{target_text} acilamadi."


def copy_to_clipboard(text: str) -> tuple[bool, str]:
    backends: list[list[str]] = []
    if command_exists("wl-copy"):
        backends.append(["wl-copy"])
    if command_exists("xclip"):
        backends.append(["xclip", "-selection", "clipboard"])
    if command_exists("xsel"):
        backends.append(["xsel", "--clipboard", "--input"])

    for command in backends:
        try:
            subprocess.run(command, input=text, text=True, check=True, timeout=5)
            return True, "ok"
        except Exception:
            continue

    try:
        import pyperclip  # type: ignore

        pyperclip.copy(text)
        return True, "ok"
    except Exception as exc:
        return False, f"Pano araci bulunamadi: {exc}"


def press_enter_after_delay(delay_seconds: float = 0.8) -> tuple[bool, str]:
    if delay_seconds > 0:
        time.sleep(delay_seconds)

    if command_exists("xdotool"):
        try:
            subprocess.run(["xdotool", "key", "Return"], check=True, timeout=5)
            return True, "ok"
        except Exception as exc:
            return False, f"xdotool Enter gonderemedi: {exc}"

    try:
        import pyautogui  # type: ignore

        pyautogui.press("enter")
        return True, "ok"
    except Exception as exc:
        return False, f"Enter otomasyonu icin xdotool veya PyAutoGUI gerekli: {exc}"


def start_audio_player(path: Path, volume: float = 0.2):
    """Start a Linux audio player for mp3/wav effects and return the Popen."""

    volume = max(0.0, min(1.0, float(volume)))
    candidates: list[list[str]] = []

    if command_exists("ffplay"):
        candidates.append(
            [
                "ffplay",
                "-nodisp",
                "-autoexit",
                "-loglevel",
                "quiet",
                "-volume",
                str(max(0, min(100, int(volume * 100)))),
                str(path),
            ]
        )
    if command_exists("mpg123"):
        candidates.append(["mpg123", "-q", "-f", str(max(0, min(32768, int(volume * 32768)))), str(path)])
    if command_exists("cvlc"):
        candidates.append(["cvlc", "--play-and-exit", "--quiet", "--gain", f"{volume:.2f}", str(path)])
    if command_exists("play"):
        candidates.append(["play", "-q", "-v", f"{volume:.2f}", str(path)])

    last_error: Exception | None = None
    for command in candidates:
        try:
            return subprocess.Popen(
                command,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
        except Exception as exc:
            last_error = exc

    if last_error:
        raise last_error
    raise FileNotFoundError("Ses oynatici bulunamadi. ffmpeg veya mpg123 kur.")
