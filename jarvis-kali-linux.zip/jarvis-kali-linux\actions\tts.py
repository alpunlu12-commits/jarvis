"""
TTS (Text-to-Speech) - Linux.

Varsayilan motor espeak-ng/espeak'tir. festival ve opsiyonel gTTS fallback
olarak desteklenir. Bu modul macOS 'say' komutunu kullanmaz.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
import threading
from pathlib import Path


VOICE = os.environ.get("JARVIS_TTS_VOICE", "tr")
BACKEND = os.environ.get("JARVIS_TTS_BACKEND", "auto").strip().lower()


def _run_espeak(text: str) -> bool:
    command = shutil.which("espeak-ng") or shutil.which("espeak")
    if not command:
        return False
    subprocess.run([command, "-v", VOICE, text], check=False)
    return True


def _run_festival(text: str) -> bool:
    command = shutil.which("festival")
    if not command:
        return False
    subprocess.run([command, "--tts"], input=text, text=True, check=False)
    return True


def _run_gtts(text: str) -> bool:
    player = shutil.which("mpg123") or shutil.which("ffplay")
    if not player:
        return False
    try:
        from gtts import gTTS  # type: ignore
    except Exception:
        return False

    tmp_path = Path(tempfile.gettempdir()) / "jarvis-tts.mp3"
    gTTS(text=text, lang=os.environ.get("JARVIS_GTTS_LANG", "tr")).save(str(tmp_path))
    if player.endswith("ffplay"):
        subprocess.run(["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", str(tmp_path)], check=False)
    else:
        subprocess.run([player, "-q", str(tmp_path)], check=False)
    try:
        tmp_path.unlink()
    except Exception:
        pass
    return True


def speak_text(text: str, on_done=None, blocking: bool = False):
    """
    Metni sesli olarak okur.
    on_done: okuma bitince cagrilacak fonksiyon (opsiyonel)
    blocking: True ise bitene kadar bekler
    """
    if not text or not text.strip():
        if on_done:
            on_done()
        return

    max_len = 500
    if len(text) > max_len:
        text = text[:max_len] + "..."

    def _run():
        try:
            if BACKEND == "espeak":
                _run_espeak(text)
            elif BACKEND == "festival":
                _run_festival(text)
            elif BACKEND == "gtts":
                _run_gtts(text)
            else:
                _run_espeak(text) or _run_festival(text) or _run_gtts(text)
        finally:
            if on_done:
                on_done()

    if blocking:
        _run()
    else:
        threading.Thread(target=_run, daemon=True).start()


def get_available_voices() -> list[str]:
    command = shutil.which("espeak-ng") or shutil.which("espeak")
    if not command:
        return []
    try:
        result = subprocess.run([command, "--voices"], capture_output=True, text=True, timeout=5)
        voices = []
        for line in result.stdout.splitlines()[1:]:
            parts = line.split()
            if len(parts) >= 4:
                voices.append(parts[3])
        return voices
    except Exception:
        return []
