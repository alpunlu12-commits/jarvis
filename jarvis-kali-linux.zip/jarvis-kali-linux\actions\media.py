"""
Medya oynatma - YouTube, Spotify ve Apple Music web.

macOS AppleScript otomasyonu kaldirildi. Linux'ta URI/URL acma icin xdg-open,
opsiyonel otomasyon icin xdotool/PyAutoGUI kullanilir.
"""

from __future__ import annotations

import shutil
import urllib.parse

from actions.browser import browser_control
from actions.linux_utils import open_with_xdg, press_enter_after_delay


def _play_youtube(query: str) -> str:
    return browser_control("play_youtube", query=query)


def _play_spotify(query: str, autoplay: bool = True) -> str:
    encoded_query = urllib.parse.quote(query.strip())
    search_uri = f"spotify:search:{encoded_query}"

    if not shutil.which("spotify"):
        ok, detail = open_with_xdg(f"https://open.spotify.com/search/{encoded_query}")
        if ok:
            return f"Spotify web aramasi acildi: {query}"
        return f"Spotify kurulu degil ve web aramasi acilamadi: {detail}"

    ok, detail = open_with_xdg(search_uri)
    if not ok:
        ok, detail = open_with_xdg(f"https://open.spotify.com/search/{encoded_query}")
        if not ok:
            return f"Spotify acilamadi: {detail}"

    if autoplay:
        press_enter_after_delay(2.0)
        return f"Spotify'da '{query}' aramasi acildi; ilk sonucu oynatma denendi."
    return f"Spotify icinde '{query}' aramasi acildi."


def _play_apple_music(query: str) -> str:
    encoded_query = urllib.parse.quote(query.strip())
    ok, detail = open_with_xdg(f"https://music.apple.com/search?term={encoded_query}")
    if ok:
        return f"Apple Music web aramasi acildi: {query}"
    return f"Apple Music web acilamadi: {detail}"


def play_media(query: str, provider: str = "auto", autoplay: bool = True) -> str:
    if not query or not query.strip():
        return "Calinacak icerik belirtilmedi."

    normalized_provider = (provider or "auto").strip().lower()
    if normalized_provider in {"yt", "youtube music"}:
        normalized_provider = "youtube"
    elif normalized_provider in {"apple music", "music", "apple_music"}:
        normalized_provider = "apple_music"

    if normalized_provider == "spotify":
        return _play_spotify(query, autoplay=autoplay)
    if normalized_provider == "apple_music":
        return _play_apple_music(query)
    if normalized_provider == "youtube":
        return _play_youtube(query)

    if shutil.which("spotify"):
        result = _play_spotify(query, autoplay=autoplay)
        if "acilamadi" not in result.lower():
            return result
    return _play_youtube(query)
