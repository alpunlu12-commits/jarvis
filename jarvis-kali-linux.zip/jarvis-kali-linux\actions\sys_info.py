"""
Sistem bilgisi - Kali/Debian Linux.
Alp Unlu tarafindan yapilmistir - @alppunlu
"""

from __future__ import annotations

import datetime
import subprocess
from pathlib import Path

try:
    import psutil

    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False


def sys_info(query: str) -> str:
    query = (query or "all").lower().strip()

    results = []
    if query in ("battery", "pil", "all"):
        results.append(_battery())
    if query in ("cpu", "islemci", "işlemci", "all"):
        results.append(_cpu())
    if query in ("ram", "bellek", "memory", "all"):
        results.append(_ram())
    if query in ("disk", "depolama", "all"):
        results.append(_disk())
    if query in ("time", "saat", "zaman", "all"):
        now = datetime.datetime.now()
        results.append(f"Saat: {now.strftime('%H:%M:%S')}")
    if query in ("date", "tarih", "all"):
        now = datetime.datetime.now()
        results.append(f"Tarih: {now.strftime('%d %B %Y, %A')}")
    if query in ("network", "ag", "ağ", "wifi", "all"):
        results.append(_network())

    if not results:
        results.append(f"Bilinmeyen sorgu: {query}. battery/cpu/ram/disk/time/date/network/all kullanin.")

    return "\n".join(r for r in results if r)


def _battery() -> str:
    if HAS_PSUTIL:
        bat = psutil.sensors_battery()
        if bat:
            status = "Sarj oluyor" if bat.power_plugged else "Pilde"
            return f"Pil: %{bat.percent:.0f} - {status}"

    for supply in Path("/sys/class/power_supply").glob("BAT*"):
        try:
            capacity = (supply / "capacity").read_text(encoding="utf-8").strip()
            status = (supply / "status").read_text(encoding="utf-8").strip()
            return f"Pil: %{capacity} - {status}"
        except Exception:
            continue
    return "Pil bilgisi alinamadi."


def _cpu() -> str:
    if HAS_PSUTIL:
        usage = psutil.cpu_percent(interval=0.5)
        count = psutil.cpu_count(logical=True)
        freq = psutil.cpu_freq()
        freq_str = f", {freq.current:.0f} MHz" if freq else ""
        return f"CPU: %{usage:.1f} kullanim - {count} cekirdek{freq_str}"

    try:
        loadavg = Path("/proc/loadavg").read_text(encoding="utf-8").split()[:3]
        return f"CPU load average: {' '.join(loadavg)}"
    except Exception:
        return "CPU bilgisi alinamadi."


def _ram() -> str:
    if HAS_PSUTIL:
        vm = psutil.virtual_memory()
        total = vm.total / (1024**3)
        used = vm.used / (1024**3)
        pct = vm.percent
        return f"RAM: {used:.1f}GB / {total:.1f}GB kullanimda (%{pct:.0f})"
    try:
        out = subprocess.check_output(["free", "-h"], text=True, timeout=5)
        for line in out.splitlines():
            if line.lower().startswith("mem:"):
                return f"RAM: {line}"
    except Exception:
        pass
    return "RAM bilgisi alinamadi."


def _disk() -> str:
    if HAS_PSUTIL:
        du = psutil.disk_usage("/")
        total = du.total / (1024**3)
        used = du.used / (1024**3)
        free = du.free / (1024**3)
        return f"Disk (/): {used:.1f}GB kullanildi, {free:.1f}GB bos (toplam {total:.1f}GB)"
    try:
        out = subprocess.check_output(["df", "-h", "/"], text=True, timeout=5)
        lines = out.strip().splitlines()
        if len(lines) >= 2:
            return f"Disk: {lines[1]}"
    except Exception:
        pass
    return "Disk bilgisi alinamadi."


def _network() -> str:
    try:
        out = subprocess.check_output(
            ["nmcli", "-t", "-f", "active,ssid", "dev", "wifi"],
            text=True,
            timeout=5,
            stderr=subprocess.DEVNULL,
        )
        for line in out.splitlines():
            active, _, ssid = line.partition(":")
            if active == "yes" and ssid:
                return f"WiFi: {ssid} bagli"
    except Exception:
        pass

    for command in (["hostname", "-I"], ["ip", "-o", "-4", "addr", "show", "scope", "global"]):
        try:
            out = subprocess.check_output(command, text=True, timeout=3, stderr=subprocess.DEVNULL).strip()
            if not out:
                continue
            if command[0] == "hostname":
                ip = out.split()[0]
            else:
                match = next((part for part in out.split() if "/" in part and part[0].isdigit()), "")
                ip = match.split("/", 1)[0] if match else ""
            if ip:
                return f"Ag: IP {ip}"
        except Exception:
            continue
    return "Ag baglantisi bulunamadi."
