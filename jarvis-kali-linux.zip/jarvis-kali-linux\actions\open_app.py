"""
Uygulama acma - Kali/Debian Linux.

macOS 'open -a' yerine once bilinen Linux komutlari, sonra gtk-launch ve
son olarak xdg-open denenir.
"""

from __future__ import annotations

import shlex
import shutil
import subprocess
from pathlib import Path

from actions.linux_utils import open_with_xdg, run_detached


APP_ALIASES: dict[str, list[str]] = {
    "browser": ["xdg-open https://www.google.com"],
    "tarayici": ["xdg-open https://www.google.com"],
    "chrome": ["google-chrome", "google-chrome-stable", "chromium", "chromium-browser"],
    "chromium": ["chromium", "chromium-browser"],
    "firefox": ["firefox", "firefox-esr"],
    "terminal": ["x-terminal-emulator", "qterminal", "xfce4-terminal", "gnome-terminal", "konsole", "xterm"],
    "konsol": ["x-terminal-emulator", "qterminal", "xfce4-terminal", "gnome-terminal", "konsole", "xterm"],
    "files": ["thunar", "nautilus", "dolphin", "pcmanfm", "xdg-open ."],
    "file manager": ["thunar", "nautilus", "dolphin", "pcmanfm", "xdg-open ."],
    "finder": ["thunar", "nautilus", "dolphin", "pcmanfm", "xdg-open ."],
    "spotify": ["spotify"],
    "vscode": ["code", "codium"],
    "vs code": ["code", "codium"],
    "code": ["code", "codium"],
    "notion": ["notion-app", "notion"],
    "slack": ["slack"],
    "discord": ["discord"],
    "whatsapp": ["whatsapp-for-linux", "whatsapp-desktop", "xdg-open https://web.whatsapp.com"],
    "telegram": ["telegram-desktop", "telegram"],
    "zoom": ["zoom"],
    "mail": ["thunderbird", "evolution", "xdg-email"],
    "calendar": ["gnome-calendar", "kalendar", "orage"],
    "takvim": ["gnome-calendar", "kalendar", "orage"],
    "notes": ["gnote", "xpad", "mousepad"],
    "notlar": ["gnote", "xpad", "mousepad"],
    "music": ["spotify", "vlc", "rhythmbox", "audacious"],
    "muzik": ["spotify", "vlc", "rhythmbox", "audacious"],
    "photos": ["shotwell", "gwenview", "ristretto", "eog"],
    "fotograflar": ["shotwell", "gwenview", "ristretto", "eog"],
    "maps": ["xdg-open https://www.google.com/maps"],
    "haritalar": ["xdg-open https://www.google.com/maps"],
    "calculator": ["gnome-calculator", "kcalc", "galculator", "xcalc"],
    "hesap makinesi": ["gnome-calculator", "kcalc", "galculator", "xcalc"],
    "settings": ["xfce4-settings-manager", "gnome-control-center", "systemsettings"],
    "ayarlar": ["xfce4-settings-manager", "gnome-control-center", "systemsettings"],
    "system settings": ["xfce4-settings-manager", "gnome-control-center", "systemsettings"],
    "activity monitor": ["gnome-system-monitor", "xfce4-taskmanager", "ksysguard", "htop"],
    "sistem monitoru": ["gnome-system-monitor", "xfce4-taskmanager", "ksysguard", "htop"],
    "preview": ["xdg-open ."],
    "onizleme": ["xdg-open ."],
    "textedit": ["mousepad", "gedit", "kate", "nano"],
    "editor": ["mousepad", "gedit", "kate", "nano"],
    "figma": ["figma-linux", "xdg-open https://www.figma.com"],
    "postman": ["postman"],
    "docker": ["docker-desktop", "xdg-open https://docs.docker.com/desktop/install/linux/"],
}


def _launch_command(command_text: str) -> tuple[bool, str]:
    parts = shlex.split(command_text)
    if not parts:
        return False, "Bos komut."

    executable = parts[0]
    if executable != "xdg-open" and not shutil.which(executable):
        return False, f"{executable} bulunamadi."
    return run_detached(parts)


def _gtk_launch(name: str) -> tuple[bool, str]:
    if not shutil.which("gtk-launch"):
        return False, "gtk-launch bulunamadi."

    candidates = []
    raw = name.strip()
    normalized = raw.lower().replace(" ", "-")
    for item in (raw, raw.lower(), normalized):
        if item:
            candidates.append(item if item.endswith(".desktop") else f"{item}.desktop")

    for desktop_id in dict.fromkeys(candidates):
        try:
            result = subprocess.run(
                ["gtk-launch", desktop_id],
                capture_output=True,
                text=True,
                timeout=5,
                check=False,
            )
        except Exception as exc:
            last_detail = str(exc)
            continue
        if result.returncode == 0:
            return True, desktop_id
        last_detail = (result.stderr or result.stdout or "").strip() or f"{desktop_id} baslatilamadi."
    return False, locals().get("last_detail", "Desktop entry bulunamadi.")


def open_app(app_name: str) -> str:
    if not app_name or not app_name.strip():
        return "Uygulama adi belirtilmedi."

    raw_name = app_name.strip()
    expanded_path = Path(raw_name).expanduser()
    if expanded_path.exists():
        ok, detail = open_with_xdg(expanded_path)
        return f"{expanded_path} acildi." if ok else f"'{expanded_path}' acilamadi: {detail}"

    normalized = raw_name.lower()
    commands = APP_ALIASES.get(normalized, [])

    for command in commands:
        ok, detail = _launch_command(command)
        if ok:
            return f"{raw_name} acildi."
        last_detail = detail

    generic_candidates = [
        raw_name,
        normalized,
        normalized.replace(" ", "-"),
        normalized.replace(" ", ""),
    ]
    for candidate in dict.fromkeys(generic_candidates):
        if shutil.which(candidate):
            ok, detail = run_detached([candidate])
            return f"{raw_name} acildi." if ok else f"'{raw_name}' acilamadi: {detail}"

    ok, detail = _gtk_launch(raw_name)
    if ok:
        return f"{raw_name} acildi."

    if raw_name.startswith(("http://", "https://")):
        ok, detail = open_with_xdg(raw_name)
        return f"{raw_name} acildi." if ok else f"URL acilamadi: {detail}"

    fallback = locals().get("last_detail", detail)
    return (
        f"'{app_name}' bulunamadi veya acilamadi. "
        f"Kali'de paket/komut kurulu mu kontrol et. Ayrinti: {fallback}"
    )
