"""
Linux reminders araci.

macOS Reminders/EventKit yerine XDG uyumlu yerel JSON deposu kullanilir:
~/.local/share/jarvis/reminders.json
"""

from __future__ import annotations

import datetime as dt
import json
import re
import time
from pathlib import Path

from actions.linux_utils import jarvis_data_dir


TR_WEEKDAYS = ["Pazartesi", "Sali", "Carsamba", "Persembe", "Cuma", "Cumartesi", "Pazar"]
TR_MONTHS = ["", "Ocak", "Subat", "Mart", "Nisan", "Mayis", "Haziran", "Temmuz", "Agustos", "Eylul", "Ekim", "Kasim", "Aralik"]


def _reminders_file() -> Path:
    return jarvis_data_dir() / "reminders.json"


def _read_reminders() -> list[dict]:
    path = _reminders_file()
    if not path.exists():
        return []
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return []
    if not isinstance(raw, list):
        return []

    items: list[dict] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        try:
            due_ts = int(item.get("due_ts", 0) or 0)
            priority = int(item.get("priority", 0) or 0)
        except (TypeError, ValueError):
            due_ts = 0
            priority = 0
        items.append(
            {
                "id": str(item.get("id", "")),
                "title": str(item.get("title", "")).strip() or "Adsiz animsatici",
                "list_name": str(item.get("list_name", "")).strip() or "JARVIS",
                "notes": str(item.get("notes", "")).strip(),
                "completed": bool(item.get("completed", False)),
                "priority": priority,
                "due_ts": due_ts,
                "all_day": bool(item.get("all_day", False)),
            }
        )
    items.sort(key=lambda item: (item["due_ts"] <= 0, item["due_ts"] or 0, item["title"].lower()))
    return items


def _write_reminders(items: list[dict]) -> None:
    path = _reminders_file()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(items, indent=2, ensure_ascii=False), encoding="utf-8")


def _normalize_query(query: str) -> tuple[str, int]:
    q = (query or "").strip().lower()
    if any(token in q for token in ("bugun", "today")):
        return "today", 8
    if any(token in q for token in ("geciken", "gecmis", "overdue")):
        return "overdue", 8
    if any(token in q for token in ("siradaki", "sıradaki", "next")):
        return "next", 1
    if any(token in q for token in ("hepsi", "tum", "tüm", "all", "listele")):
        return "all", 10
    return "upcoming", 8


def _day_label(when: dt.datetime, now: dt.datetime) -> str:
    today = now.date()
    target = when.date()
    if target == today:
        return "bugun"
    if target == today + dt.timedelta(days=1):
        return "yarin"
    return f"{when.day} {TR_MONTHS[when.month]} {TR_WEEKDAYS[when.weekday()]}"


def _format_due(item: dict, now: dt.datetime) -> str:
    if item["due_ts"] <= 0:
        return "zaman atanmamis"
    due = dt.datetime.fromtimestamp(item["due_ts"])
    if item["all_day"]:
        return f"{_day_label(due, now)} tum gun"
    return f"{_day_label(due, now)} {due.strftime('%H:%M')}"


def _format_reminder_line(item: dict, now: dt.datetime) -> str:
    parts = [f"{_format_due(item, now)} - {item['title']}"]
    if item["list_name"]:
        parts.append(f"[{item['list_name']}]")
    if item["priority"] >= 1:
        parts.append("(yuksek oncelik)")
    return " ".join(parts)


def _filter_items(mode: str, items: list[dict], list_name: str) -> list[dict]:
    now = dt.datetime.now()
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    tomorrow_start = today_start + dt.timedelta(days=1)
    list_norm = (list_name or "").strip().casefold()

    open_items = [item for item in items if not item["completed"]]
    if list_norm:
        open_items = [item for item in open_items if item["list_name"].casefold() == list_norm]

    if mode == "today":
        start_ts = int(today_start.timestamp())
        end_ts = int(tomorrow_start.timestamp())
        return [item for item in open_items if start_ts <= item["due_ts"] < end_ts]
    if mode == "overdue":
        return [item for item in open_items if 0 < item["due_ts"] < int(now.timestamp())]
    if mode == "next":
        return [item for item in open_items if item["due_ts"] >= int(now.timestamp())][:1]
    if mode == "all":
        return open_items
    return [item for item in open_items if item["due_ts"] == 0 or item["due_ts"] >= int(now.timestamp())]


def get_reminders(query: str = "upcoming", limit: int = 8, list_name: str = "") -> str:
    mode, default_limit = _normalize_query(query)
    limit = max(1, min(20, int(limit or default_limit)))
    reminders = _filter_items(mode, _read_reminders(), list_name)[:limit]

    if not reminders:
        suffix = f" (Yerel dosya: {_reminders_file()})"
        if mode == "today":
            return "Bugun icin animsatici gorunmuyor." + suffix
        if mode == "overdue":
            return "Geciken animsatici gorunmuyor." + suffix
        if mode == "next":
            return "Siradaki animsaticiyi bulamadim." + suffix
        if mode == "all":
            return "Kayitli acik animsatici gorunmuyor." + suffix
        return "Yaklasan animsatici gorunmuyor." + suffix

    now = dt.datetime.now()
    if mode == "next":
        return f"Siradaki animsatici: {_format_reminder_line(reminders[0], now)}."

    if mode == "today":
        header = f"Bugun icin {len(reminders)} animsatici buldum:"
    elif mode == "overdue":
        header = f"Gecikmis {len(reminders)} animsatici buldum:"
    elif mode == "all":
        header = f"Acik {len(reminders)} animsatici buldum:"
    else:
        header = f"Yaklasan {len(reminders)} animsatici buldum:"

    lines = [header]
    for item in reminders:
        lines.append(f"- {_format_reminder_line(item, now)}")
    return "\n".join(lines)


def _normalize_due_iso(due_iso: str) -> tuple[str, bool]:
    raw = (due_iso or "").strip()
    if not raw:
        return "", False

    candidates = (
        ("%Y-%m-%dT%H:%M:%S", False),
        ("%Y-%m-%dT%H:%M", False),
        ("%Y-%m-%d %H:%M:%S", False),
        ("%Y-%m-%d %H:%M", False),
        ("%d.%m.%Y %H:%M", False),
        ("%d/%m/%Y %H:%M", False),
        ("%Y-%m-%d", True),
        ("%d.%m.%Y", True),
        ("%d/%m/%Y", True),
    )

    if raw.endswith("Z"):
        try:
            parsed = dt.datetime.fromisoformat(raw.replace("Z", "+00:00")).astimezone().replace(tzinfo=None)
            return parsed.isoformat(timespec="minutes"), False
        except ValueError:
            pass

    if re.match(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}", raw):
        try:
            parsed = dt.datetime.fromisoformat(raw).replace(tzinfo=None)
            return parsed.isoformat(timespec="minutes"), False
        except ValueError:
            pass

    for fmt, is_all_day in candidates:
        try:
            parsed = dt.datetime.strptime(raw, fmt)
            if is_all_day:
                return parsed.date().isoformat(), True
            return parsed.isoformat(timespec="minutes"), False
        except ValueError:
            continue

    raise ValueError("Animsatici tarihi gecersiz. due_iso icin 'YYYY-MM-DD' veya 'YYYY-MM-DDTHH:MM' kullan.")


def _priority_value(priority: str) -> int:
    normalized = (priority or "").strip().lower()
    if normalized in {"high", "yuksek", "yüksek", "1"}:
        return 1
    if normalized in {"medium", "orta", "5"}:
        return 5
    if normalized in {"low", "dusuk", "düşük", "9"}:
        return 9
    return 0


def add_reminder(
    title: str,
    due_iso: str = "",
    notes: str = "",
    list_name: str = "",
    priority: str = "",
    all_day: bool = False,
) -> str:
    if not title or not title.strip():
        return "Animsatici basligi bos olamaz."

    due_ts = 0
    normalized_all_day = bool(all_day)
    if due_iso and due_iso.strip():
        try:
            normalized_due, inferred_all_day = _normalize_due_iso(due_iso)
        except ValueError as exc:
            return str(exc)
        normalized_all_day = normalized_all_day or inferred_all_day
        if inferred_all_day:
            parsed_due = dt.datetime.strptime(normalized_due, "%Y-%m-%d")
        else:
            parsed_due = dt.datetime.fromisoformat(normalized_due)
        due_ts = int(parsed_due.timestamp())

    item = {
        "id": f"rem-{int(time.time() * 1000)}",
        "title": title.strip(),
        "due_ts": due_ts,
        "notes": (notes or "").strip(),
        "list_name": (list_name or "JARVIS").strip(),
        "priority": _priority_value(priority),
        "all_day": normalized_all_day,
        "completed": False,
    }
    reminders = _read_reminders()
    reminders.append(item)
    reminders.sort(key=lambda x: (x["due_ts"] <= 0, x["due_ts"] or 0, x["title"].lower()))
    _write_reminders(reminders)

    now = dt.datetime.now()
    when = _format_due(item, now)
    list_suffix = f" [{item['list_name']}]" if item["list_name"] else ""
    return f"Animsatici eklendi: {when} - {item['title']}{list_suffix}"
