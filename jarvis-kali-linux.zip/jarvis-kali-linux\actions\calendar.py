"""
Linux takvim araci.

macOS EventKit/Swift helper kaldirildi. Etkinlikler XDG uyumlu yerel JSON
deposunda tutulur: ~/.local/share/jarvis/calendar_events.json
JARVIS_DATA_DIR ile farkli bir konum verilebilir.
"""

from __future__ import annotations

import datetime as dt
import json
import re
import time
from pathlib import Path

from actions.linux_utils import jarvis_data_dir


TR_WEEKDAYS = ["Pazartesi", "Sali", "Carsamba", "Persembe", "Cuma", "Cumartesi", "Pazar"]
TR_MONTHS = ["", "Ocak", "Subat", "Mart", "Nisan", "Mayis", "Haziran", "Temmuz", "Agustos", "Eylul", "Ekim", "Kasim", "Aralik"]


def _calendar_file() -> Path:
    return jarvis_data_dir() / "calendar_events.json"


def _read_events() -> list[dict]:
    path = _calendar_file()
    if not path.exists():
        return []
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return []
    if not isinstance(raw, list):
        return []

    events: list[dict] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        try:
            start_ts = int(item.get("start_ts", 0))
            end_ts = int(item.get("end_ts", 0))
        except (TypeError, ValueError):
            continue
        if start_ts <= 0 or end_ts <= 0:
            continue
        events.append(
            {
                "id": str(item.get("id", "")),
                "start_ts": start_ts,
                "end_ts": end_ts,
                "calendar": str(item.get("calendar", "")).strip() or "JARVIS",
                "title": str(item.get("title", "")).strip() or "Adsiz etkinlik",
                "location": str(item.get("location", "")).strip(),
                "notes": str(item.get("notes", "")).strip(),
                "all_day": bool(item.get("all_day", False)),
            }
        )
    events.sort(key=lambda event: (event["start_ts"], event["title"].lower()))
    return events


def _write_events(events: list[dict]) -> None:
    path = _calendar_file()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(events, indent=2, ensure_ascii=False), encoding="utf-8")


def _month_start(value: dt.datetime) -> dt.datetime:
    return value.replace(day=1, hour=0, minute=0, second=0, microsecond=0)


def _add_months(value: dt.datetime, months: int) -> dt.datetime:
    total = (value.year * 12 + (value.month - 1)) + months
    year = total // 12
    month = total % 12 + 1
    return value.replace(year=year, month=month, day=1)


def _parse_datetime(raw: str, all_day: bool = False) -> tuple[dt.datetime, bool]:
    value = (raw or "").strip()
    if not value:
        raise ValueError("Tarih bos olamaz.")

    if value.endswith("Z"):
        try:
            parsed = dt.datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone().replace(tzinfo=None)
            return parsed, False
        except ValueError:
            pass

    if re.match(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}", value):
        try:
            return dt.datetime.fromisoformat(value).replace(tzinfo=None), False
        except ValueError:
            pass

    candidates = (
        ("%Y-%m-%d %H:%M:%S", False),
        ("%Y-%m-%d %H:%M", False),
        ("%d.%m.%Y %H:%M", False),
        ("%d/%m/%Y %H:%M", False),
        ("%Y-%m-%d", True),
        ("%d.%m.%Y", True),
        ("%d/%m/%Y", True),
    )
    for fmt, is_date_only in candidates:
        try:
            parsed = dt.datetime.strptime(value, fmt)
            return parsed, all_day or is_date_only
        except ValueError:
            continue
    raise ValueError("Tarih formati gecersiz. Ornek: 2026-05-28T14:30 veya 2026-05-28 14:30")


def _normalize_query(query: str) -> dict:
    q = (query or "today").strip().lower()
    now = dt.datetime.now()
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)

    month_match = re.search(r"(\d+)\s*(ay|month|months)", q)
    if "gelecek ay" in q or "onumuzdeki ay" in q or "önümüzdeki ay" in q or "next month" in q:
        start = _add_months(_month_start(now), 1)
        end = _add_months(start, 1)
        return {"start": start, "end": end, "default_limit": 24, "kind": "next_month", "header": "Gelecek ay icin {count} etkinlik buldum:", "empty": "Gelecek ay takviminde etkinlik gorunmuyor."}
    if "bu ay" in q or "this month" in q:
        start = _month_start(now)
        end = _add_months(start, 1)
        return {"start": start, "end": end, "default_limit": 24, "kind": "this_month", "header": "Bu ay icin {count} etkinlik buldum:", "empty": "Bu ay takviminde etkinlik gorunmuyor."}
    if month_match:
        months = max(1, min(12, int(month_match.group(1))))
        start = today_start
        end = _add_months(_month_start(now), months)
        return {"start": start, "end": end, "default_limit": min(60, max(12, months * 12)), "kind": "months", "header": f"Onumuzdeki {months} ay icin {{count}} etkinlik buldum:", "empty": f"Onumuzdeki {months} ayda takviminde etkinlik gorunmuyor."}

    week_match = re.search(r"(\d+)\s*(hafta|week|weeks)", q)
    if week_match:
        weeks = max(1, min(12, int(week_match.group(1))))
        start = today_start
        end = today_start + dt.timedelta(days=weeks * 7)
        return {"start": start, "end": end, "default_limit": min(60, max(8, weeks * 8)), "kind": "weeks", "header": f"Onumuzdeki {weeks} hafta icin {{count}} etkinlik buldum:", "empty": f"Onumuzdeki {weeks} haftada takviminde etkinlik gorunmuyor."}

    day_match = re.search(r"(\d+)\s*(g[uü]n|gun|day|days)", q)
    if day_match:
        days = max(1, min(365, int(day_match.group(1))))
        start = today_start
        end = today_start + dt.timedelta(days=days)
        return {"start": start, "end": end, "default_limit": min(60, max(8, days * 2)), "kind": "days", "header": f"Onumuzdeki {days} gun icin {{count}} etkinlik buldum:", "empty": f"Onumuzdeki {days} gunde takviminde etkinlik gorunmuyor."}

    if any(token in q for token in ("yarin", "tomorrow")):
        start = today_start + dt.timedelta(days=1)
        return {"start": start, "end": start + dt.timedelta(days=1), "default_limit": 6, "kind": "tomorrow", "header": "Yarin icin {count} etkinlik buldum:", "empty": "Yarin takviminde etkinlik gorunmuyor."}
    if any(token in q for token in ("hafta", "week", "7 gun")):
        return {"start": today_start, "end": today_start + dt.timedelta(days=7), "default_limit": 10, "kind": "week", "header": "Onumuzdeki 7 gun icin {count} etkinlik buldum:", "empty": "Onumuzdeki 7 gunde takviminde etkinlik gorunmuyor."}
    if any(token in q for token in ("siradaki", "sıradaki", "sonraki", "next")):
        return {"start": now, "end": today_start + dt.timedelta(days=365), "default_limit": 1, "kind": "next", "header": "", "empty": "Siradaki takvim etkinligini bulamadim."}
    if any(token in q for token in ("ajanda", "agenda", "yaklasan", "yaklaşan", "upcoming")):
        return {"start": now, "end": today_start + dt.timedelta(days=365), "default_limit": 8, "kind": "agenda", "header": "Yaklasan ajandanda {count} etkinlik var:", "empty": "Yaklasan takvim etkinligi gorunmuyor."}
    return {"start": today_start, "end": today_start + dt.timedelta(days=1), "default_limit": 6, "kind": "today", "header": "Bugun icin {count} etkinlik buldum:", "empty": "Bugun takviminde etkinlik gorunmuyor."}


def _day_label(when: dt.datetime, now: dt.datetime) -> str:
    today = now.date()
    target = when.date()
    if target == today:
        return "bugun"
    if target == today + dt.timedelta(days=1):
        return "yarin"
    return f"{when.day} {TR_MONTHS[when.month]} {TR_WEEKDAYS[when.weekday()]}"


def _format_time_range(event: dict, now: dt.datetime) -> str:
    start = dt.datetime.fromtimestamp(event["start_ts"])
    end = dt.datetime.fromtimestamp(event["end_ts"])
    prefix = _day_label(start, now)
    if event["all_day"]:
        return f"{prefix} tum gun"
    return f"{prefix} {start.strftime('%H:%M')}-{end.strftime('%H:%M')}"


def _format_event_line(event: dict, now: dt.datetime) -> str:
    pieces = [f"{_format_time_range(event, now)} - {event['title']}"]
    if event["calendar"]:
        pieces.append(f"[{event['calendar']}]")
    if event["location"]:
        pieces.append(f"@ {event['location']}")
    return " ".join(pieces)


def _overlaps(event: dict, start: dt.datetime, end: dt.datetime) -> bool:
    start_ts = int(start.timestamp())
    end_ts = int(end.timestamp())
    return event["end_ts"] >= start_ts and event["start_ts"] < end_ts


def get_calendar_events(query: str = "today", limit: int = 6) -> str:
    window = _normalize_query(query)
    limit = max(1, min(60, int(limit or window["default_limit"])))
    events = [event for event in _read_events() if _overlaps(event, window["start"], window["end"])]

    now = dt.datetime.now()
    if window["kind"] in {"next", "agenda"}:
        events = [event for event in events if event["end_ts"] >= int(now.timestamp())]

    if not events:
        return window["empty"] + f" (Yerel takvim dosyasi: {_calendar_file()})"

    if window["kind"] == "next":
        return f"Siradaki etkinlik: {_format_event_line(events[0], now)}."

    selected = events[:limit]
    header = str(window["header"]).format(count=len(selected))
    lines = [header]
    for event in selected:
        lines.append(f"- {_format_event_line(event, now)}")
    return "\n".join(lines)


def add_calendar_event(
    title: str,
    start_iso: str,
    end_iso: str = "",
    notes: str = "",
    location: str = "",
    calendar_name: str = "",
    all_day: bool = False,
) -> str:
    title = (title or "").strip()
    start_iso = (start_iso or "").strip()
    if not title:
        return "Takvime eklemek icin etkinlik basligi gerekli."
    if not start_iso:
        return "Takvime eklemek icin baslangic tarihi gerekli."

    try:
        start, inferred_all_day = _parse_datetime(start_iso, all_day=all_day)
        all_day = bool(all_day or inferred_all_day)
        if end_iso and end_iso.strip():
            end, _ = _parse_datetime(end_iso, all_day=all_day)
        else:
            end = start + (dt.timedelta(days=1) if all_day else dt.timedelta(hours=1))
    except ValueError as exc:
        return str(exc)

    if end <= start:
        return "Bitis tarihi baslangictan sonra olmali."

    event = {
        "id": f"evt-{int(time.time() * 1000)}",
        "title": title,
        "start_ts": int(start.timestamp()),
        "end_ts": int(end.timestamp()),
        "calendar": (calendar_name or "JARVIS").strip(),
        "notes": (notes or "").strip(),
        "location": (location or "").strip(),
        "all_day": all_day,
    }
    events = _read_events()
    events.append(event)
    events.sort(key=lambda item: (item["start_ts"], item["title"].lower()))
    _write_events(events)

    return f"Takvime eklendi: {_format_event_line(event, dt.datetime.now())}."


def delete_calendar_event(
    title: str,
    start_iso: str = "",
    calendar_name: str = "",
    delete_all_matches: bool = False,
) -> str:
    title = (title or "").strip()
    if not title:
        return "Takvimden silmek icin etkinlik basligi gerekli."

    start_filter: dt.datetime | None = None
    if start_iso and start_iso.strip():
        try:
            start_filter, _ = _parse_datetime(start_iso)
        except ValueError as exc:
            return str(exc)

    title_norm = title.casefold()
    calendar_norm = (calendar_name or "").strip().casefold()

    events = _read_events()
    matches = []
    for event in events:
        if title_norm not in event["title"].casefold():
            continue
        if calendar_norm and calendar_norm != event["calendar"].casefold():
            continue
        if start_filter:
            event_start = dt.datetime.fromtimestamp(event["start_ts"])
            if abs((event_start - start_filter).total_seconds()) > 24 * 3600:
                continue
        matches.append(event)

    if not matches:
        return f"'{title}' icin silinecek takvim etkinligi bulunamadi."

    if len(matches) > 1 and not delete_all_matches:
        now = dt.datetime.now()
        preview = " | ".join(_format_event_line(event, now) for event in matches[:5])
        return f"Birden fazla eslesme var. Tarih ver veya delete_all_matches=true kullan. Eslesmeler: {preview}"

    ids_to_delete = {event["id"] for event in (matches if delete_all_matches else matches[:1])}
    remaining = [event for event in events if event["id"] not in ids_to_delete]
    _write_events(remaining)

    now = dt.datetime.now()
    if delete_all_matches and len(matches) > 1:
        return f"{len(matches)} takvim etkinligi silindi."
    return f"Takvimden silindi: {_format_event_line(matches[0], now)}."
